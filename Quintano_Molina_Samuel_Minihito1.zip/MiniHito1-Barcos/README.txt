Samuel Quintano Molina

El juego comienza con una bienvenida en la que especificas el tamaño del tablero 
y el numero maximo de barcos que quieres, esto crea el tablero de forma personalizada.

He usado objetos, tablero, barco, y utilidades.
Barco contiene informacion y datos del barco, posicion, tamaño etc
Tablero contiene la logica de creacion y colocacion de barcos.
Y utilidades me sirve para crear de forma aleatoria los barcos, 
tanto el tamaño como la orientacion.